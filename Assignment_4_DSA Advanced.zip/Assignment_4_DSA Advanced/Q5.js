class Graph {
    constructor(vertices) {
      this.vertices = vertices;
      this.adjacencyList = new Map();
    }
  
    addVertex(vertex) {
      this.adjacencyList.set(vertex, []);
    }
  
    addEdge(source, destination) {
      this.adjacencyList.get(source).push(destination);
    }
  
    hasCycle() {
      const visited = new Set();
      const recStack = new Set();
  
      const isCyclic = (vertex) => {
        if (!visited.has(vertex)) {
          visited.add(vertex);
          recStack.add(vertex);
  
          const neighbors = this.adjacencyList.get(vertex);
  
          for (const neighbor of neighbors) {
            if (!visited.has(neighbor) && isCyclic(neighbor)) {
              return true;
            } else if (recStack.has(neighbor)) {
              return true;
            }
          }
        }
        recStack.delete(vertex);
        return false;
      };
  
      for (const vertex of this.adjacencyList.keys()) {
        if (isCyclic(vertex)) {
          return true;
        }
      }
  
      return false;
    }
  }
  
  const graph = new Graph(4);
  graph.addVertex(0);
  graph.addVertex(1);
  graph.addVertex(2);
  graph.addVertex(3);
  graph.addEdge(0, 1);
  graph.addEdge(1, 2);
  graph.addEdge(2, 3);
  graph.addEdge(3, 0); 
  
  if (graph.hasCycle()) {
    console.log("The graph has a cycle.");
  } else {
    console.log("The graph does not have a cycle.");
  }
  