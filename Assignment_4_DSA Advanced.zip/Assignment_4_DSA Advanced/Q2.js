class Node {
    constructor(val) {
      this.val = val;
      this.neighbors = [];
    }
  }
  
  function dfs(graph, startNode) {
    const visited = new Set();
    const stack = [startNode];
  
    while (stack.length > 0) {
      const node = stack.pop();
      visited.add(node);
      console.log(node.val);
      for (const neighbor of node.neighbors) {
        if (!visited.has(neighbor)) {
          stack.push(neighbor);
        }
      }
    }
  }
  const graph = new Node(1);
  graph.neighbors.push(new Node(2));
  graph.neighbors.push(new Node(3));
  dfs(graph, graph);