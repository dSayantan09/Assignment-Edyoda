const forestGrid = [
    [1, 0, 1, 1, 0],
    [0, 1, 0, 1, 1],
    [1, 1, 1, 0, 0],
    [0, 0, 0, 1, 0],
    [1, 0, 1, 0, 1],
  ];
  
  function countTreesInForest(forest) {
    let treeCount = 0;
    for (let i = 0; i < forest.length; i++) {
      for (let j = 0; j < forest[i].length; j++) {
        if (forest[i][j] === 1) {
          treeCount++;
        }
      }
    } 
    return treeCount;
  }
  
  const numberOfTrees = countTreesInForest(forestGrid);
  console.log(`Number of trees in the forest: ${numberOfTrees}`);  