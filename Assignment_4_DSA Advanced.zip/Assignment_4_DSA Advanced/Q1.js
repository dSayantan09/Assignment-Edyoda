class Node {
    constructor(val) {
      this.val = val;
      this.neighbors = [];
    }
  }
  
  function bfs(graph, startNode) {
    const visited = new Set();
    const queue = [startNode];
  
    while (queue.length > 0) {
      const node = queue.shift();
      visited.add(node);
      console.log(node.val);
      for (const neighbor of node.neighbors) {
        if (!visited.has(neighbor)) {
          queue.push(neighbor);
        }
      }
    }
  }
  const graph = new Node(1);
  graph.neighbors.push(new Node(2));
  graph.neighbors.push(new Node(3));
  bfs(graph, graph);
  