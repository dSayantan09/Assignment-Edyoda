class Node {
    constructor(val) {
      this.val = val;
      this.level = 0;
      this.neighbors = [];
    }
  }
  
  function bfsCountNodesAtLevel(tree, level) {
    const visited = new Set();
    const queue = [tree];
  
    let count = 0;
  
    while (queue.length > 0) {
      const node = queue.shift();
      visited.add(node);
      if (node.level === level) {
        count++;
      }
      for (const neighbor of node.neighbors) {
        if (!visited.has(neighbor)) {
          neighbor.level = node.level + 1;
          queue.push(neighbor);
        }
      }
    }
  
    return count;
  }
  
  const tree = new Node(1);
  tree.neighbors.push(new Node(2));
  tree.neighbors.push(new Node(3));
  tree.neighbors[0].neighbors.push(new Node(4));
  tree.neighbors[0].neighbors.push(new Node(5));
  const count = bfsCountNodesAtLevel(tree, 2);
  console.log(count);