const listOfStrings = ["apple", "banana", "cherry", "date", "apricot"];
listOfStrings.sort();
console.log("Sorted list of strings:", listOfStrings);
