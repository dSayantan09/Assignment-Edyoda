class TreeNode {
    constructor(value) {
      this.value = value;
      this.left = null;
      this.right = null;
    }
  }
  
  class BinaryTree {
    constructor() {
      this.root = null;
    }
  
    insert(value) {
      const newNode = new TreeNode(value);
  
      if (!this.root) {
        this.root = newNode;
      } else {
        this._insertNode(this.root, newNode);
      }
    }
  
    _insertNode(node, newNode) {
      if (newNode.value < node.value) {
        if (node.left === null) {
          node.left = newNode;
        } else {
          this._insertNode(node.left, newNode);
        }
      } else {
        if (node.right === null) {
          node.right = newNode;
        } else {
          this._insertNode(node.right, newNode);
        }
      }
    }
  
    // Breadth-First Search (BFS)
    bfs() {
      const result = [];
      const queue = [this.root];
  
      while (queue.length > 0) {
        const currentNode = queue.shift();
        if (currentNode !== null) {
          result.push(currentNode.value);
          queue.push(currentNode.left);
          queue.push(currentNode.right);
        }
      }
  
      return result;
    }
  
    // Depth-First Search (DFS) - In-order
    dfsInOrder() {
      const result = [];
      this._dfsInOrder(this.root, result);
      return result;
    }
  
    _dfsInOrder(node, result) {
      if (node === null) {
        return;
      }
  
      this._dfsInOrder(node.left, result);
      result.push(node.value);
      this._dfsInOrder(node.right, result);
    }
  
    // Depth-First Search (DFS) - Pre-order
    dfsPreOrder() {
      const result = [];
      this._dfsPreOrder(this.root, result);
      return result;
    }
  
    _dfsPreOrder(node, result) {
      if (node === null) {
        return;
      }
  
      result.push(node.value);
      this._dfsPreOrder(node.left, result);
      this._dfsPreOrder(node.right, result);
    }
  
    // Depth-First Search (DFS) - Post-order
    dfsPostOrder() {
      const result = [];
      this._dfsPostOrder(this.root, result);
      return result;
    }
  
    _dfsPostOrder(node, result) {
      if (node === null) {
        return;
      }
  
      this._dfsPostOrder(node.left, result);
      this._dfsPostOrder(node.right, result);
      result.push(node.value);
    }
  }
  
  const tree = new BinaryTree();
  tree.insert(10);
  tree.insert(5);
  tree.insert(15);
  tree.insert(3);
  tree.insert(7);
  tree.insert(12);
  
  console.log("BFS:", tree.bfs());                 
  console.log("DFS (In-order):", tree.dfsInOrder());
  console.log("DFS (Pre-order):", tree.dfsPreOrder());
  console.log("DFS (Post-order):", tree.dfsPostOrder());