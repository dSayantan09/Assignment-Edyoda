function countSubtreesWithSumX(root, x) {
    if (!root) {
      return 0;
    }
    let count = countSubtreesWithSumX(root.left, x) +
                countSubtreesWithSumX(root.right, x);
  
    if (root.data === x) {
      count++;
    }
  
    return count;
  }
  
  const root = {
    data: 3,
    left: {
      data: 9,
      left: null,
      right: null,
    },
    right: {
      data: 20,
      left: {
        data: 15,
        left: null,
        right: null,
      },
      right: {
        data: 7,
        left: null,
        right: null,
      },
    },
  };
  
  const x = 15;
  const count = countSubtreesWithSumX(root, x);
  console.log(count);