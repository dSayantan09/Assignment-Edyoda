class PerfectBinaryTree {
    constructor(height) {
      this.height = height;
    }
  
    sumOfNodes() {
      return Math.pow(2, this.height) - 1;
    }
  }
  
  const height = 3;
  const tree = new PerfectBinaryTree(height);
  console.log("Sum of all nodes:", tree.sumOfNodes());