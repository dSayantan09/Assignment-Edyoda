class TreeNode {
    constructor(value) {
      this.value = value;
      this.left = null;
      this.right = null;
    }
  }
  
  class BinaryTree {
    constructor() {
      this.root = null;
    }
  
    insert(value) {
      const newNode = new TreeNode(value);
  
      if (!this.root) {
        this.root = newNode;
      } else {
        this._insertNode(this.root, newNode);
      }
    }
  
    _insertNode(node, newNode) {
      if (newNode.value < node.value) {
        if (node.left === null) {
          node.left = newNode;
        } else {
          this._insertNode(node.left, newNode);
        }
      } else {
        if (node.right === null) {
          node.right = newNode;
        } else {
          this._insertNode(node.right, newNode);
        }
      }
    }
  
    // Pre-order traversal (root, left, right)
    preOrderTraversal() {
      const result = [];
      this._preOrder(this.root, result);
      return result;
    }
  
    _preOrder(node, result) {
      if (node === null) {
        return;
      }
  
      result.push(node.value);
      this._preOrder(node.left, result);
      this._preOrder(node.right, result);
    }
  
    // In-order traversal (left, root, right)
    inOrderTraversal() {
      const result = [];
      this._inOrder(this.root, result);
      return result;
    }
  
    _inOrder(node, result) {
      if (node === null) {
        return;
      }
  
      this._inOrder(node.left, result);
      result.push(node.value);
      this._inOrder(node.right, result);
    }
  
    // Post-order traversal (left, right, root)
    postOrderTraversal() {
      const result = [];
      this._postOrder(this.root, result);
      return result;
    }
  
    _postOrder(node, result) {
      if (node === null) {
        return;
      }
  
      this._postOrder(node.left, result);
      this._postOrder(node.right, result);
      result.push(node.value);
    }
  }
  
  
  const tree = new BinaryTree();
  tree.insert(10);
  tree.insert(5);
  tree.insert(15);
  tree.insert(3);
  tree.insert(7);
  tree.insert(12);
  
  console.log("Pre-order traversal:", tree.preOrderTraversal());   
  console.log("In-order traversal:", tree.inOrderTraversal());     
  console.log("Post-order traversal:", tree.postOrderTraversal());
  