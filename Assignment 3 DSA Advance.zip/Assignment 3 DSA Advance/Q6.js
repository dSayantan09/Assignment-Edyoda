function sumOfLeftLeaves(root) {
    if (!root) {
      return 0;
    }
    if (!root.right && !root.left) {
      return root.data;
    }
    let leftSum = sumOfLeftLeaves(root.left);
    let rightSum = sumOfLeftLeaves(root.right);
    return leftSum + rightSum;
  }
  
  const root = {
    data: 3,
    left: {
      data: 9,
      left: null,
      right: null,
    },
    right: {
      data: 20,
      left: {
        data: 15,
        left: null,
        right: null,
      },
      right: {
        data: 7,
        left: null,
        right: null,
      },
    },
  };
  const sum = sumOfLeftLeaves(root);
  console.log(sum);