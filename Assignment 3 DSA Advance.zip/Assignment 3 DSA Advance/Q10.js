class TreeNode {
    constructor(value) {
      this.value = value;
      this.left = null;
      this.right = null;
    }
  }
  
  class BinaryTree {
    constructor() {
      this.root = null;
    }
  
    insert(value) {
      const newNode = new TreeNode(value);
  
      if (!this.root) {
        this.root = newNode;
      } else {
        this._insertNode(this.root, newNode);
      }
    }
  
    _insertNode(node, newNode) {
      if (newNode.value < node.value) {
        if (node.left === null) {
          node.left = newNode;
        } else {
          this._insertNode(node.left, newNode);
        }
      } else {
        if (node.right === null) {
          node.right = newNode;
        } else {
          this._insertNode(node.right, newNode);
        }
      }
    }
  
    printOddLevelNodes() {
      if (!this.root) {
        return;
      }
  
      const queue = [{ node: this.root, level: 1 }];
  
      while (queue.length > 0) {
        const { node, level } = queue.shift();
  
        if (level % 2 === 1) {
          console.log("Node at odd level:", node.value);
        }
  
        if (node.left) {
          queue.push({ node: node.left, level: level + 1 });
        }
  
        if (node.right) {
          queue.push({ node: node.right, level: level + 1 });
        }
      }
    }
  }
  
  const tree = new BinaryTree();
  tree.insert(1);
  tree.insert(2);
  tree.insert(3);
  tree.insert(4);
  tree.insert(5);
  tree.insert(6);
  tree.insert(7);
  
  console.log("Nodes at odd levels:");
  tree.printOddLevelNodes(); 
  