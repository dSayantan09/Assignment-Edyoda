var url =
  "http://www.filltext.com/?rows=32&id=%7Bnumber%7C1000%7D&firstName=%7BfirstName%7D&lastName=%7BlastName%7D&email=%7Bemail%7D&phone=%7Bphone%7C(xxx)xxx-xx-xx%7D&address=%7BaddressObject%7D&description=%7Blorem%7C32%7D";

const tableContainer = document.querySelector("#table-data");
let activeRow;
let tableData;

function fillInfo(){
    const infoContainer = document.querySelector("#info-content");
    infoContainer.style.display = "block";
    const infoData = tableData.find((item) => item.id.toString() === activeRow.querySelector(".column1").innerHTML.toString());
    infoContainer.innerHTML = `<div><b>User selected:</b> ${infoData.firstName} ${infoData.lastName}</div>
                                <div>
                                    <b>Description: </b>
                                    <textarea cols="50" rows="5" readonly>
                                        ${infoData.description}
                                    </textarea>
                                </div>
                                <div><b>Address:</b> ${infoData.address.streetAddress}</div>
                                <div><b>City:</b> ${infoData.address.city}</div>
                                <div><b>State:</b> ${infoData.address.state}</div>
                                <div><b>Zip:</b> ${infoData.address.zip}</div>`;
}

function clickEventHandler(){
    tableContainer.querySelector("table").querySelector("tbody").querySelectorAll("tr").forEach((row) => {
        row.addEventListener("click", () => {
            if(activeRow) {
                activeRow.classList.remove("active");
            }
            row.classList.add("active");
            activeRow = row;
            fillInfo();
        });
    });
}

function getTableData() {
  fetch(url)
    .then((resp) => {
      resp
        .json()
        .then((res) => {
            tableData = res;
          const tBody = tableContainer
            .querySelector("table")
            .querySelector("tbody");
          tBody.innerHTML = "";
          res.forEach((item) => {
            const tr = document.createElement("tr");
            tr.setAttribute("class", "data-row");
            tr.innerHTML = `<td class="column1">${item.id}</td>
                                <td class="column2">${item.firstName}</td>
                                <td class="column3">${item.lastName}</td>
                                <td class="column4">${item.email}</td>
                                <td class="column5">${item.phone}</td>`;
            tBody.appendChild(tr);
            clickEventHandler();
          });
        })
        .catch((err) => {
          console.log(err);
        });
    })
    .catch((err) => {
      console.log(err);
    });
};

getTableData();

const searchInput = document.querySelector("#search-box");
const tBody = tableContainer.querySelector("table").querySelector("tbody");
searchInput.addEventListener("keyup", () => {
  const searchValue = searchInput.value;
  const dataRows = tBody.querySelectorAll(".data-row");
  dataRows.forEach((row) => {
    const columns = row.querySelectorAll("td");
    let found = false;
    columns.forEach((column) => {
      if (
        column.innerHTML.toLowerCase().indexOf(searchValue.toLowerCase()) > -1
      ) {
        found = true;
      }
    });
    if (found) {
      row.style.display = "";
    } else {
      row.style.display = "none";
    }
  });
});
