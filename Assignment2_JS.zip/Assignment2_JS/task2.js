/* Question 2:
Write a program to print following pattern in the console.
54321
5432
543
54
5 */

function printPattern(rows) {
    for (var i = 0; i < rows; i++) {
      var pattern = "";
      for (var j = rows; j > i; j--) {
        pattern += j;
      }
      console.log(pattern);
    }
  }  
printPattern(5);
  