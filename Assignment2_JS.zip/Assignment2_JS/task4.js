// Question 4:
// Write a JavaScript program to check if two strings are anagrams. Anagram string are such two strings which can be rearranged to create one another.
// For example,
// Input: LISTEN and SILENT
// Output: True
// Input: HELLO and JELLO
// Output: False

function anagrams(str1, str2) {
    str1 = str1.toLowerCase().replace(/\s/g, '');
    str2 = str2.toLowerCase().replace(/\s/g, '');
    if (str1.length != str2.length) {
      return false;
    }
    var char1 = {};
    var char2 = {};
    for (var char of str1) {
      char1[char] = (char1[char] || 0) + 1;
    }
  
    for (var char of str2) {
      char2[char] = (char2[char] || 0) + 1;
    }
    for (var char in char1) {
      if (char1[char] != char2[char]) {
        return false;
      }
    }
  
    return true;
  }
  
  var word_1 = prompt("Enter the first word: ");
  var word_2 = prompt("Enter the second word: ");
  
  if (anagrams(word_1, word_2)) {
    document.write("The strings are anagrams.");
  } 
  else {
    document.write("The strings are not anagrams.");
  }
  