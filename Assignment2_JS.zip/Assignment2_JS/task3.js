// Question 3:
// Write a JavaScript program to sort an array in ascending order
// For example,
// Input: [3, 2, 1, 4, 5, 45]
// Output: [1, 2, 3, 4, 5, 45]


var arr = [];
var size = Number(prompt("Enter the size of the array: "));

for(var i=0; i<size; i++) {
	arr[i] = prompt('Enter elements of the array: ' + (i+1));
}
document.write("The array is: -" + arr + "<br>");
var result=arr.sort();
document.write("The sorted array is: -",result);