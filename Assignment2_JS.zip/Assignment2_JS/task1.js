/*Question 1:
Write a program to search if a number exists in an array. If the number exists then return the position. If it exists multiple time then return an array with all the positions. If the number doesn't exist then return -1;
For example,
Input: [1, 2, 3, 4, 5, 1, 3] and Search Elem: 4
Output: 3
Input: [1, 2, 3, 4, 5, 1, 3] and Search Elem: 1
Output: [0, 5]
Input: [1, 2, 3, 4, 5, 1, 3] and Search Elem: 7
Output: -1 */

function searchNumberInArray(arr, number) {
    var positions = [];
    
    for (var i = 0; i < arr.length; i++) {
      if (arr[i] == number) {
        positions.push(i);
      }
    }
    
    if (positions.length == 0) {
      return -1;
    } else {
      return positions.length == 1 ? positions[0] : positions;
    }
  }
    
  var arr = [];
  var size = Number(prompt("Enter the size of the array: "));

  for(var i=0; i<size; i++) {
	  arr[i] = prompt('Enter elements of the array: ' + (i+1));
  }
  document.write("The array is: -" + arr + "<br>");
  var number = prompt('Enter a number to search in the array');
  
  var result = searchNumberInArray(arr, number);
  document.write("The position of the "+ number +" in the array is --> "+result+"<br>");