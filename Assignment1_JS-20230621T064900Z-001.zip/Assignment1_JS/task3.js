// Question 3:
// Write a JavaScript program to create menu driven calculator that performs basic arithmetic operations (add, subtract, multiply and divide) using switch case. The calculator should input two numbers and an operator: +, -, *, / from the user. It should perform operation according to the operator entered and must take input in given format.

var num1 = parseFloat(prompt("Enter first number: "));
var num2 = parseFloat(prompt("Enter second number: "));

var operator = prompt("Enter operator from the list: +, -, *, /: ");
switch(operator){
    case "+":
        result = num1 + num2;
        result1= result.toFixed(2);
        document.write("The result of the addition is : " + result1+ "<br>");
        break;
    case "-":
        result = num1 - num2;
        result1= result.toFixed(2);
        document.write("The result of the subtraction is : " + result1+ "<br>");
        break;
    case "*":
        result = num1 * num2;
        result1= result.toFixed(2);
        document.write("The result of the multiplication is : " + result1+ "<br>");
        break;
    case "/":
        result = num1 / num2;
        result1= result.toFixed(2);
        document.write("The result of the division is : " + result1+ "<br>");
        break;
    default:
        document.write("Invalid operator"+"<br>");
        break;
}

