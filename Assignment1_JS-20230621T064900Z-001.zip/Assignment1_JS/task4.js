// Question 4:
// Write a JavaScript program to input sides of a triangle and check whether a triangle is equilateral, scalene or isosceles triangle using if else.
// Properties of triangle:
// A triangle is said Equilateral Triangle, if all its sides are equal. If a, b, c are three sides of triangle. Then, the triangle is equilateral only if a == b == c.
// A triangle is said Isosceles Triangle, if its two sides are equal. If a, b, c are three sides of triangle. Then, the triangle is isosceles if either a == b or a == c or b == c.
// A triangle is said Scalene Triangle, if none of its sides are equal.

function triangle (a, b, c) {
    if (a == b && b == c && c == a) {
        document.write("The given triangle is an equilateral Triangle");
    }
    else if (a == b || a == c || b == c) {
            document.write("The given triangle is an isosceles Triangle");
        }
    else if (a!= b && a!= c && b!= c) {
            document.write("The given triangle is a scalene Triangle");
        }
}

var a= parseFloat(prompt("Enter the first side of the triangle"));
var b= parseFloat(prompt("Enter the second side of the triangle"));
var c= parseFloat(prompt("Enter the third side of the triangle"));

triangle(a, b, c);
