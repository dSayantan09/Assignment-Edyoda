// Write a program to reverse an array in place? In place means you cannot create a new array. You have to update the original array.

function reverseArray(arr) {
    for (let i = 0; i < arr.length / 2; i++) {
      let temp = arr[i];
      arr[i] = arr[arr.length - 1 - i];
      arr[arr.length - 1 - i] = temp;
    }
  }
  
  let arr = [11,22,"Sayantan", true, "Das", 33.56, -9, false];
  console.log(arr);
  reverseArray(arr);
  console.log(arr);