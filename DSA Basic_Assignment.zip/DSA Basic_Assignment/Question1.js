// Write a program to find all pairs of an integer array whose sum is equal to a given number?

function findPairs(arr, sum) {
    let pairs = [];
    let map = new Map();
    
    for (let i = 0; i < arr.length; i++) {
      let complement = sum - arr[i];
      
      if (map.has(complement)) {
        pairs.push([complement, arr[i]]);
      }
      
      map.set(arr[i], i);
    }
    
    return pairs;
  }
  
  let arr = [11,22,33,44,55,66,77,88,99];
  let sum = 88;
  let pairs = findPairs(arr, sum);
  console.log(pairs);