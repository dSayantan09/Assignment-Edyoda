//Write a program to find the smallest number using a stack.

class MinStack {
    constructor() {
      this.items = [];
      this.minValues = [];
    }
  
    push(element) {
      this.items.push(element);
  
      if (this.minValues.length === 0 || element <= this.getMin()) {
        this.minValues.push(element);
      }
    }
  
    pop() {
      if (this.isEmpty()) {
        return "Underflow";
      }
  
      let poppedElement = this.items.pop();
      if (poppedElement === this.getMin()) {
        this.minValues.pop();
      }
  
      return poppedElement;
    }
  
    peek() {
      return this.items[this.items.length - 1];
    }
  
    isEmpty() {
      return this.items.length === 0;
    }
  
    size() {
      return this.items.length;
    }
  
    getMin() {
      if (this.minValues.length === 0) {
        return Infinity; // Assuming stack is not empty, we return Infinity for an empty minValues stack
      }
      return this.minValues[this.minValues.length - 1];
    }
  
    print() {
      console.log(this.items);
    }
  }
  
  let myStack = new MinStack();
  myStack.push(-5);
  myStack.push(-2);
  myStack.push(-8);
  myStack.push(-10);
  myStack.push(50);
  myStack.push(22);
  myStack.push(83);
  myStack.push(19);

  console.log("Original Stack:");
  myStack.print();
  console.log("Smallest Number in the Stack:", myStack.getMin());
  