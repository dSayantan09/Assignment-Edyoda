// Read about infix, prefix, and postfix expressions. Write a program to convert postfix to prefix expression & to convert prefix expression to infix expression.

/* 
A. Infix Notation:
Infix notation is the most common way of representing arithmetic expressions that we are familiar with. 
It places operators between the operands. For example, the infix expression "3 + 4" means adding 3 and 4.

B. Prefix Notation:
Also known as Polish notation, it places operators to the left of the operands.
For example, the prefix expression "+ 3 4" means adding 3 and 4. The operator comes first, followed by its operands. 
To handle multiple operations, each operator must have the correct number of operands.

C. Postfix Notation:
Also known as Reverse Polish notation, it places operators to the right of the operands.
For example, the postfix expression "3 4 +" means adding 3 and 4. The operator comes last, after its operands.
To handle multiple operations, each operator must have the correct number of operands.

*/

//Program to implement Postfix to Prefix Conversion Algorithm

function isOperator(char) {
    return ['+', '-', '*', '/', '^'].includes(char);
  }
  
  function postfixToPrefix(postfixExpression) {
    var stack = [];
  
    for (var char of postfixExpression) {
      if (!isOperator(char)) {
        stack.push(char);
      } else {
        var operand2 = stack.pop();
        var operand1 = stack.pop();
        var prefixExpression = char + operand1 + operand2;
        stack.push(prefixExpression);
      }
    }
  
    return stack.pop();
  }
  
  var postfixExpr = "11+5*";
  var prefixExpr = postfixToPrefix(postfixExpr);
  console.log("Postfix Expression:", postfixExpr);
  console.log("Prefix Expression:", prefixExpr);

  
//Program to implement Prefix to Infix Conversion Algorithm

function isOperator(char) {
  return ['+', '-', '*', '/', '^'].includes(char);
}

function prefixToInfix(prefixExpression) {
  var stack = [];

  for (var i = prefixExpression.length - 1; i >= 0; i--) {
    var char = prefixExpression[i];

    if (!isOperator(char)) {
      stack.push(char);
    } else {
      var operand1 = stack.pop();
      var operand2 = stack.pop();
      var infixExpression = `(${operand1}${char}${operand2})`;
      stack.push(infixExpression);
    }
  }

  return stack.pop();
}

var prefixExpr = "*+115";
var infixExpr = prefixToInfix(prefixExpr);
console.log("Prefix Expression:", prefixExpr);
console.log("Infix Expression:", infixExpr);