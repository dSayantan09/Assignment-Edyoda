// Write a program to print the first non-repeated character from a string?

function firstNoRepeat(str) {
    let charCount = new Map();
    
    for (let i = 0; i < str.length; i++) {
      let char = str[i];
      charCount.set(char, (charCount.get(char) || 0) + 1);
    }
    
    for (let i = 0; i < str.length; i++) {
      let char = str[i];
      
      if (charCount.get(char) === 1) {
        return char;
      }
    }
    
    return null;
  }
  
  let str = "sayantan Das";
  let result = firstNoRepeat(str);
  console.log(result);