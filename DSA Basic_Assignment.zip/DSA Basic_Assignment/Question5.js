// Read about the Tower of Hanoi algorithm. Write a program to implement it.

/* 
Tower of Hanoi is a math puzzle where we have 3 rods and n disks.
This n disks are arranged in the following manner:
A. only one disk can be moved at a time. 
B. Each move consists of taking the upper disk from one of the stacks & placing it 
   on top of another stack.
C. No disk may be placed on top of a smaller disk.
*/

//Program to implement Tower of Hanoi algorithm.


function towerOfHanoi(n, source, auxiliary, destination) {
  if (n === 1) {
    console.log(`Move disk 1 from ${source} to ${destination}`);
    return;
  }
  towerOfHanoi(n - 1, source, destination, auxiliary);
  console.log(`Move disk ${n} from ${source} to ${destination}`);
  towerOfHanoi(n - 1, auxiliary, source, destination);
}
let numDisks = 3;
towerOfHanoi(numDisks, 'A', 'B', 'C');
