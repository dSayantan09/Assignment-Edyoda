//Write a program to reverse a stack

class Stack {
    constructor() {
      this.items = [];
    }
  
    push(element) {
      this.items.push(element);
    }
  
    pop() {
      if (this.isEmpty()) {
        return "Underflow";
      }
      return this.items.pop();
    }
  
    peek() {
      return this.items[this.items.length - 1];
    }
  
    isEmpty() {
      return this.items.length === 0;
    }
  
    size() {
      return this.items.length;
    }
  
    print() {
      console.log(this.items);
    }
  }
  
  function reverseStack(stack) {
    let auxiliaryStack = new Stack();
  
    while (!stack.isEmpty()) {
      auxiliaryStack.push(stack.pop());
    }
  
    return auxiliaryStack;
  }
  
  let myStack = new Stack();
  myStack.push(1);
  myStack.push(12);
  myStack.push(31);
  myStack.push(14);
  myStack.push(10);
  myStack.push(22);
  myStack.push(33);
  myStack.push(46);
  myStack.push(11);
  myStack.push(20);
  myStack.push(36);
  myStack.push(45);
  myStack.push(15);
  myStack.push(23);
  myStack.push(34);
  myStack.push(4);
  
  console.log("Original Stack:");
  myStack.print();
  let reversedStack = reverseStack(myStack);
  console.log("Reversed Stack:");
  reversedStack.print();
  