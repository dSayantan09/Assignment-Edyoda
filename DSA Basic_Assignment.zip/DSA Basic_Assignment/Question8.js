//Write a program to check if all the brackets are closed in a given code snippet.

function areBracketsClosed(codeSnippet) {
    let stack = [];
    let openBrackets = ['(', '[', '{'];
    let closeBrackets = [')', ']', '}'];
  
    for (let char of codeSnippet) {
      if (openBrackets.includes(char)) {
        stack.push(char);
      } else if (closeBrackets.includes(char)) {
        let lastOpenBracket = stack.pop();
        let expectedOpenBracket = openBrackets[closeBrackets.indexOf(char)];
  
        if (lastOpenBracket !== expectedOpenBracket) {
          return false;
        }
      }
    }
  
    return stack.length === 0;
  }
  
  let codeSnippet1 = "function foo() { return (a + b); }";
  console.log(areBracketsClosed(codeSnippet1));
  
  let codeSnippet2 = "if (a * (b + c) > 5 { console.log('Valid!'); }";
  console.log(areBracketsClosed(codeSnippet2));
