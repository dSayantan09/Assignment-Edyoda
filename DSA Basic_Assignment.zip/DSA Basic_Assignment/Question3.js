// Write a program to check if two strings are a rotation of each other?

function stringRotation(str1, str2) {
    if (str1.length !== str2.length) {
      return false;
    }
    
    let concat = str1 + str1;
    
    return concat.includes(str2);
  }
  
  var str1 = "Sayantan Das";
  var str2 = "Das Sayantan";
  var result = stringRotation(str1, str2);
  console.log(result);

  var str1 = "abcd";
  var str2 = "cdab";
  var result = stringRotation(str1, str2);
  console.log(result);