function moveNegativesToOneSide(arr) {
    let left = 0; 
    let right = arr.length - 1; 
  
    while (left <= right) {
      if (arr[left] < 0 && arr[right] < 0) {
        left++;
      } else if (arr[left] >= 0 && arr[right] < 0) {
        const temp = arr[left];
        arr[left] = arr[right];
        arr[right] = temp;
        left++;
        right--;
      } else if (arr[left] >= 0 && arr[right] >= 0) {
        right--;
      } else {
  
        left++;
        right--;
      }
    }
  }
  
  const arr = [-1, 3, -4, 5, -6, 2, 8, -9];
  console.log("Original Array:", arr);
  
  moveNegativesToOneSide(arr);
  
  console.log("Array with Negative Elements Moved to One Side:", arr);
  