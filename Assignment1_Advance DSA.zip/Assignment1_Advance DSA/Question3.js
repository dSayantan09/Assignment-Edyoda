class Node {
    constructor(value) {
      this.value = value;
      this.next = null;
    }
  }
  
  class LinkedList {
    constructor() {
      this.head = null;
    }
  
    append(value) {
      const newNode = new Node(value);
      if (!this.head) {
        this.head = newNode;
      } else {
        let current = this.head;
        while (current.next) {
          current = current.next;
        }
        current.next = newNode;
      }
    }
  
    mergeAlternate(otherList) {
      if (!otherList.head) {
        return;
      }
  
      let current1 = this.head;
      let current2 = otherList.head;
  
      while (current1 && current2) {
        const next1 = current1.next;
        const next2 = current2.next;
  
        current1.next = current2;
        current2.next = next1;
  
        current1 = next1;
        current2 = next2;
      }
  
      otherList.head = null; 
    }
  
    printList() {
      let current = this.head;
      const values = [];
  
      while (current) {
        values.push(current.value);
        current = current.next;
      }
  
      console.log(values.join(' -> '));
    }
  }
  

  const list1 = new LinkedList();
  list1.append(1);
  list1.append(2);
  list1.append(3);
  
  const list2 = new LinkedList();
  list2.append('A');
  list2.append('B');
  
  console.log("List 1:");
  list1.printList();
  console.log("List 2:");
  list2.printList();
  
  list1.mergeAlternate(list2);
  
  console.log("Merged List:");
  list1.printList();
  