function findKthSmallestAndLargest(arr, k) {
    arr.sort((a, b) => a - b); 
    const kthSmallest = arr[k - 1];
  
    arr.sort((a, b) => b - a); 
    const kthLargest = arr[k - 1];
  
    return { kthSmallest, kthLargest };
  }
  
  const arr = [12, 3, 1, 9, 45, 6];
  const k = 3;
  const { kthSmallest, kthLargest } = findKthSmallestAndLargest(arr, k);
  
  console.log(`Kth Smallest: ${kthSmallest}`);
  console.log(`Kth Largest: ${kthLargest}`);
  