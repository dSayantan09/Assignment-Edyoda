class Node {
    constructor(value) {
      this.value = value;
      this.next = null;
    }
  }
  
  class LinkedList {
    constructor() {
      this.head = null;
    }
  
    append(value) {
      const newNode = new Node(value);
      if (!this.head) {
        this.head = newNode;
      } else {
        let current = this.head;
        while (current.next) {
          current = current.next;
        }
        current.next = newNode;
      }
    }
  
    deleteElementsWithZeroSum() {
      let current = this.head;
      let sum = 0;
      const sumMap = new Map();
      let prev = null;
  
      while (current) {
        sum += current.value;
  
        if (sum === 0) {
          if (prev) {
            prev.next = current.next;
          } else {
            this.head = current.next;
          }
        } else if (sumMap.has(sum)) {
    
          const prevNode = sumMap.get(sum).next;
          let temp = prevNode.next;
          while (temp !== current) {
            prevNode.next = temp.next;
            temp = temp.next;
          }
        } else {
          sumMap.set(sum, prev);
        }
  
        prev = current;
        current = current.next;
      }
    }
  
    printList() {
      let current = this.head;
      const values = [];
  
      while (current) {
        values.push(current.value);
        current = current.next;
      }
  
      console.log(values.join(' -> '));
    }
  }
  
  const list = new LinkedList();
  list.append(3);
  list.append(4);
  list.append(-7);
  list.append(5);
  list.append(-6);
  list.append(6);
  
  console.log("Original list:");
  list.printList();
  
  list.deleteElementsWithZeroSum();
  
  console.log("List after deleting elements with zero sum:");
  list.printList();
  