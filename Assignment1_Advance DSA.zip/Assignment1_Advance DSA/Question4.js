function countPairsWithSum(arr, sum) {
    const elementCount = {}; 
    let pairCount = 0;
  
    for (let i = 0; i < arr.length; i++) {
      const currentElement = arr[i];
      const complement = sum - currentElement;

      if (elementCount[complement]) {
        pairCount += elementCount[complement];
      }

      if (elementCount[currentElement]) {
        elementCount[currentElement]++;
      } else {
        elementCount[currentElement] = 1;
      }
    }
  
    return pairCount;
  }

  const arr = [1, 2, 3, 4, 5, 6, 7, 8, 9];
  const sum = 10;
  const result = countPairsWithSum(arr, sum);
  console.log(`Pairs with sum ${sum}: ${result}`);
  