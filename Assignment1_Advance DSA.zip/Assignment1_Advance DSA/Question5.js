function findDuplicates(arr) {
    arr.sort();
    const duplicates = [];
  
    for (let i = 1; i < arr.length; i++) {
      if (arr[i] === arr[i - 1]) {
        duplicates.push(arr[i]);
      }
    }
  
    return duplicates;
  }
  
  const arr = [1, 2, 3, 4, 2, 5, 6, 7, 3];
  const duplicates = findDuplicates(arr);
  console.log("Duplicates:", duplicates);
  