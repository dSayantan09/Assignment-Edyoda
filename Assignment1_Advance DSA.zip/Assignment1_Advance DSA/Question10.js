class QueueUsingStacks {
    constructor() {
      this.stack1 = [];
      this.stack2 = [];
    }
  
    enqueue(item) {
      this.stack1.push(item);
    }
  
    dequeue() {
      if (this.stack2.length === 0) {
        if (this.stack1.length === 0) {
          return undefined;
        }
        while (this.stack1.length > 0) {
          this.stack2.push(this.stack1.pop());
        }
      }
      return this.stack2.pop();
    }
  
    isEmpty() {
      return this.stack1.length === 0 && this.stack2.length === 0;
    }
  
    size() {
      return this.stack1.length + this.stack2.length;
    }
  }
  

  const queue = new QueueUsingStacks();
  queue.enqueue(1);
  queue.enqueue(2);
  queue.enqueue(3);
  
  console.log("Dequeue:", queue.dequeue()); 
  console.log("Dequeue:", queue.dequeue()); 
  
  queue.enqueue(4);
  console.log("Size:", queue.size()); 
  
  console.log("Dequeue:", queue.dequeue()); 
  console.log("Dequeue:", queue.dequeue()); 
  
  console.log("Is Empty:", queue.isEmpty()); 
  