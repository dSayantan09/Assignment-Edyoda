class Node {
    constructor(value) {
      this.value = value;
      this.next = null;
    }
  }
  
  class LinkedList {
    constructor() {
      this.head = null;
    }
  
    append(value) {
      const newNode = new Node(value);
      if (!this.head) {
        this.head = newNode;
      } else {
        let current = this.head;
        while (current.next) {
          current = current.next;
        }
        current.next = newNode;
      }
    }
  
    reverseInGroups(groupSize) {
      if (groupSize <= 1 || !this.head) {
        return;
      }
  
      let current = this.head;
      let prevGroupTail = null;
      let newHead = null;
  
      while (current) {
        let groupStart = current;
        let prev = null;
        let next = null;
        let count = 0;
  
        while (current && count < groupSize) {
          next = current.next;
          current.next = prev;
          prev = current;
          current = next;
          count++;
        }
  
        if (!newHead) {
          newHead = prev;
        }
  
        if (prevGroupTail) {
          prevGroupTail.next = prev;
        }
  
        prevGroupTail = groupStart;
      }
  
      this.head = newHead;
    }
  
    printList() {
      let current = this.head;
      const values = [];
  
      while (current) {
        values.push(current.value);
        current = current.next;
      }
  
      console.log(values.join(' -> '));
    }
  }
  
  const list = new LinkedList();
  list.append(1);
  list.append(2);
  list.append(3);
  list.append(4);
  list.append(5);
  list.append(6);
  list.append(7);
  list.append(8);
  
  console.log("Original list:");
  list.printList();
  
  const groupSize = 3;
  list.reverseInGroups(groupSize);
  
  console.log(`List after reversing in groups of ${groupSize}:`);
  list.printList();
  