function reverseString(str) {
    const stack = [];
    const reversedString = [];
    for (let i = 0; i < str.length; i++) {
      stack.push(str[i]);
    }
    while (stack.length > 0) {
      reversedString.push(stack.pop());
    }
    return reversedString.join('');
  }
  
  const originalString = "Hello, World!";
  const reversed = reverseString(originalString);
  
  console.log("Original String:", originalString);
  console.log("Reversed String:", reversed);
  