function evaluatePostfixExpression(expression) {
    const stack = [];
    function isOperator(token) {
      return token === '+' || token === '-' || token === '*' || token === '/';
    }

    function performOperation(operator, operand1, operand2) {
      switch (operator) {
        case '+':
          return operand1 + operand2;
        case '-':
          return operand1 - operand2;
        case '*':
          return operand1 * operand2;
        case '/':
          if (operand2 === 0) {
            throw new Error('Division by zero');
          }
          return operand1 / operand2;
      }
    }
  
    const tokens = expression.split(' ');
  
    for (const token of tokens) {
      if (!isOperator(token)) {
        stack.push(parseFloat(token)); 
      } else {
        const operand2 = stack.pop();
        const operand1 = stack.pop();
        const result = performOperation(token, operand1, operand2);
        stack.push(result);
      }
    }
  
    if (stack.length !== 1) {
      throw new Error('Invalid postfix expression');
    }
  
    return stack[0];
  }

  const postfixExpression = "3 4 * 2 / 5 +";
  const result = evaluatePostfixExpression(postfixExpression);
  
  console.log(`Postfix Expression: ${postfixExpression}`);
  console.log(`Result: ${result}`);
  